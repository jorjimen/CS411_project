/*
 Configuration information for MongoDB. DO NOT push this to github
 */
const MongoDB = {
    dbURI: 'mongodb+srv://edwardzw:mongodb8517310test@cluster0-43xr4.mongodb.net/test?retryWrites=true&w=majority',
    cookieKey: 'siogoiaosmdangiuahjisoj'
}

module.exports = MongoDB
