/*
 Configuration information for Spotify API authorization. DO NOT push this to github
 */
const Spotify = {
    CLIENT_ID: '321c7d8fdd214088975a04ad18321da4',
    CLIENT_SECRET: '4874c38c143845db8fdce3dce26604dc',
}

module.exports = Spotify
