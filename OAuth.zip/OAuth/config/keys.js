/*
 Configuration information for Keys. DO NOT push this to github
 */

module.exports = {
    session: {
        cookieKey: 'ioiasjtioasflksandksa'
    }
}